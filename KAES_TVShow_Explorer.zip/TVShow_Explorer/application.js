angular.module('showExplorer', ['ngMaterial','ngResource']);
angular.module('showExplorer').constant('ApiUrl','http://www.omdbapi.com/');
angular.module('showExplorer').constant('MonthNames',[
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
]);